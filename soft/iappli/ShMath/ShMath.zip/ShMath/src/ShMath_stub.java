/*
 * ShMath_stub.java
 *
 * Copyright 2008 . All rights reserved.
 */
import com.nttdocomo.ui.IApplication;

/**
 * ShMath_stub
 *
 * @author  Shogo
 * @version 1.00,2008/08/30 21:00
 */
public class ShMath_stub extends IApplication {

    public void start() {
    	int i;
    	for(i=1;i<10000;i++) {
    		ShReal real = ShFloat.getFloat(""+(i/10000.0));
    		double d = Double.parseDouble(real.toString());
    		double out1 = Double.parseDouble(ShReal.sqrt(real).toString());
    		double out2 = Math.sqrt(d);
    		double res = out1/out2;
    		System.out.print(real + ":" + out1 + "," + out2);
    		if(0.99999999<=res && res<=1.00000001) System.out.println("OK");
    		else break;
    	}
    }
}
