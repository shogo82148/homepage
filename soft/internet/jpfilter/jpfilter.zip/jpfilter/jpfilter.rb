#!/usr/bin/ruby

$: << File.dirname(__FILE__)

require 'webrick'
#require 'webrick/ssl'
require 'webrick/httpproxy'
require 'punycode'

handler = Proc.new() {|req,res|
	if req.unparsed_uri =~ /api\.twitter\.com/ and res['content-type'] =~ /application\/json/
		res.body.gsub!(/(https?:\\\/\\\/)((?:[-_.!~*'()a-zA-Z0-9;?:@&=+$,%#]|\\[uU][0-9a-fA-F]{4})+\.(?:jp|com|net|biz|nu|la|ac))(\\\/([-_.!~*'()a-zA-Z0-9;?:@&=+$,%#]|\\\/)*)?/) { |s|
			protocol = $1
			domain = $2
			file = $3.nil? ? '' : $3
			domain=domain.split('.')
			domain.map! {|name|
				if name.match(/\\[uU][0-9a-fA-F]{4}/)
					name.gsub!(/\\[uU]([0-9a-fA-F]{4})/){[$1.to_i(16)].pack('U')}
					"xn--"+Punycode.encode(name)
				else
					name
				end
			}
			ponycode = protocol + domain.join('.') + file
			if s=~/https?:\\\/\\\/([-_.!~*'()a-zA-Z0-9;?:@&=+$,%#]|\\\/)+/
				s
			else
				s+' ( '+ponycode+' ) '
			end
		}
		res.header.delete("content-length")
	end
	if req.unparsed_uri =~ /api\.twitter\.com/ and res['content-type'] =~ /application\/xml/
		res.body.gsub!(/(https?:\/\/)((?:[-_.!~*'()a-zA-Z0-9;?:@=+$,%#]|&#\d+;)+\.(?:jp|com|net|biz|nu|la|ac))(\/([-_.!~*'()a-zA-Z0-9;?:@=+$,%#\/]|&amp;)*)?/) { |s|
			protocol = $1
			domain = $2
			file = $3.nil? ? '' : $3
			domain=domain.split('.')
			domain.map! {|name|
				if name=~ /^([-_.!~*'()a-zA-Z0-9;?:@=+$,%#\/]|&amp;)+$/
					name
				else
					name.gsub!(/&#(\d+);/){[$1.to_i].pack('U')}
					"xn--"+Punycode.encode(name)
				end
			}
			ponycode = protocol + domain.join('.') + file
			if s =~ /https?:\/\/([-_.!~*'()a-zA-Z0-9;?:@=+$,%#\/]|&amp;)+/
				s
			else
				s+' ( '+ponycode+' ) '
			end
		}
		res.header.delete("content-length")
	end
}

# プロキシサーバオブジェクトを作る
s = WEBrick::HTTPProxyServer.new(
:Port=>8080,
:ProxyContentHandler=>handler
)

# SIGINT を捕捉する。
Signal.trap('INT') do
	# 捕捉した場合、シャットダウンする。
	s.shutdown
end

# サーバを起動する。
#WEBrick::Daemon.start {
s.start
#}
