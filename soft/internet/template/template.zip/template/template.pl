use POSIX 'strftime';

$inputdir = './src';
$outputdir = './out';
$directory = '';
$templatedir = './template';
$docopy = 0;

for($i=0;$i<=$#ARGV;$i++) {
	$arg = $ARGV[$i];
	if($arg eq '-i' || $arg eq '--input') {
		$inputdir = $ARGV[++$i];
	} elsif($arg eq '-o' || $arg eq '--output') {
		$outputdir = $ARGV[++$i];
	} elsif($arg eq '-t' || $arg eq '--template') {
		$templatedir = $ARGV[++$i];
	} elsif($arg eq '-c' || $arg eq '--copyfile') {
		$docopy = 1;
	} elsif($arg eq '-d' || $arg eq '--directory') {
		$directory = $ARGV[++$i];
	}
}

#�Ō��'/'�͍폜
$inputdir =~ s/\/$//;
$outputdir =~ s/\/$//;
$templatedir =~ s/\/$//;

if($directory ne '') {
	$outputdir .= $directory;
}

&process;

sub process {
	local($nestlv=0, $tamplate_update=0);
	
	#�e���v���[�g�̓ǂݍ���
	local($template="");
	print STDERR "reading $templatedir/template.html...\n";
	open(TEMPLATE, "$templatedir/template.html");
	$tamplate_update = (-M "$templatedir/template.html");
	while(<TEMPLATE>) {
		$template .= $_;
	}
	
	#�����J�n
	&copy_template($templatedir, $outputdir);
	&process_dir($inputdir, $outputdir, "");
	print "done\n";
}

#�e���v���[�g���R�s�[����
sub copy_template {
	my ($indir, $outdir, $filename, @files, $fullpath);
	$indir = $_[0];
	$outdir = $_[1];
	
	#�o�̓f�B���N�g�������݂��Ă��Ȃ���΍쐬
	unless(-d $outdir) {
		print STDERR "make directory $outdir\n";
		mkdir($outdir, 777);
	}
	
	#�f�B���N�g�����J��
	opendir(INDIR, $indir) or die "cannot open directory $indir: $!";
	@files = readdir INDIR;
	closedir(INDIR) or die "cannot close directory $indir: $!";
	
	foreach $filename(@files) {
		next if($filename eq '.' || $filename eq '..' || $filename eq '.svn' || $filename eq 'Thumbs.db');
		$fullpath = $indir.'/'.$filename;
		if(-d $fullpath) {
			#�f�B���N�g���������ꍇ�̏���
			$nestlv++;
			copy_template($fullpath, $outdir.'/'.$filename);
			$nestlv--;
		} elsif($filename ne "template.html") {
			#�t�@�C���������ꍇ�̏���
			copy_file($indir.'/'.$filename, $outdir.'/'.$filename);
		}
	}
	
}

#�f�B���N�g������������
sub process_dir {
	my($indir, $outdir, $filename, @files, $fullpath);
	my($virtualdir);
	my($num_item);
	
	$indir = $_[0];
	$outdir = $_[1];
	$virtualdir = $_[2];
	
	#�o�̓f�B���N�g�������݂��Ă��Ȃ���΍쐬
	unless(-d $outdir) {
		print STDERR "make directory $outdir\n";
		mkdir($outdir, 777);
	}
	
	#�f�B���N�g�����J��
	opendir(INDIR, $indir) or die "cannot open directory $indir: $!";
	@files = readdir INDIR;
	closedir(INDIR) or die "cannot close directory $indir: $!";
	
	$num_item = 0;
	foreach $filename(@files) {
		next if($filename eq '.' || $filename eq '..' || $filename =~ /^~/ || $filename eq '.svn' || $filename eq 'Thumbs.db');
		$fullpath = $indir.'/'.$filename;
		if(-d $fullpath) {
			#�f�B���N�g���������ꍇ�̏���
			$nestlv++;
			&process_dir($fullpath, $outdir.'/'.$filename, $virtualdir.'/'.$filename);
			$nestlv--;
		} elsif($filename =~ m/\.s?html?$/) {
			#HTML�t�@�C���������ꍇ�̏���
			&process_file($indir.'/'.$filename, $outdir.'/'.$filename, $virtualdir);
		} elsif($docopy) {
			&copy_file($indir.'/'.$filename, $outdir.'/'.$filename);
		} else {
			next;
		}
		$num_item++;
	}
	
	#���g������̃f�B���N�g���͍폜
	rmdir($outdir) if($num_item==0);
}

#�t�@�C������������
sub process_file {
	local($infile, $indir, @ifnest);
	local %echovar = ();
	local($config_timefmt="%A, %d-%b-%Y %H:%M:%S %Z", $config_sizefmt = "bytes");
	local($contents,$menu);
	my($outfile, $output, $virtualdir);
	$infile = $_[0];
	$outfile = $_[1];
	$virtualdir = $_[2];
	@ifnest = (1);
	
	#���łɑ��݂��A�ύX����Ă��Ȃ��ꍇ�A�������X�L�b�v
	return if( (-f $outfile) && (-M $infile)>(-M $outfile) && $tamplate_update>(-M $outfile));
	
	print STDERR "processing $infile...\n";
	
	#���ϐ���ݒ�
	if($infile =~ m|^(.*)/([^/]*)$|) {
		$indir = $1;
		$echovar{"document_name"} = $2;
	} else {
		$indir = "";
		$echovar{"document_name"} = $infile;
	}
	$echovar{"last_modified"} = strftime $config_timefmt, localtime($filestat[9]);
	my @filestat = stat $infile;
	
	#�Ǝ��g��
	if($nestlv==0) {
		$echovar{"relroot"} = "./";
	} else {
		$echovar{"relroot"} = "../" x $nestlv;
	}
	if($diectory ne '') {
		$echovar{"path"} = "./";
	} else {
		$echovar{"path"} = $echovar{"relroot"} . "../" . $virtualdir. "/";
		$echovar{"path"} =~ s|//|/|g;
	}
	$echovar{"menu_file"} = "~menu.html";
	
	#�R�}���h������
	$output = &process_str($template);
	
	#��������
	open(OUT, ">".$outfile) or die "cannot open $outfile: $!";
	print OUT $output;
	close(OUT) or die "cannot close $outfile: $!";
}

sub process_str {
	my($line, $outputline, $output, @lines);
	@lines = split(/\r\n|\r|\n/, $_[0]);
	$output = '';
	foreach $line(@lines) {
		$outputline = $line;
		$outputline =~ s/<\!--#(.*?) -->/&process_cmd($1)/eg;
		next if(!$ifnest[0]);
		next if(!($line =~ /^\s*$/) && $outputline =~ /^\s*$/);
		$output .= "$outputline\n";
	}
	return $output;
}

#�t�@�C�����R�s�[����
sub copy_file {
	my($infile,$outfile);
	$infile = $_[0];
	$outfile = $_[1];
	
	#���łɑ��݂��A�ύX����Ă��Ȃ��ꍇ�A�������X�L�b�v
	return if( (-f $outfile) && (-M $infile)>(-M $outfile));
	
	print STDERR "copying $infile...\n";
	
	open(IN, $infile) or die "cannot open $infile: $!";
	open(OUT, ">".$outfile) or die "cannot open $outfile: $!";
	
	binmode(IN);
	binmode(OUT);
	while(<IN>) {
		print OUT $_;
	}
	
	close(IN) or die "cannot close $infile: $!";
	close(OUT) or die "cannot close $outfile: $!";
}

#�R�}���h�̎��s
sub process_cmd {
	local ($cmd, $name, %arg, $targetfile);
	#�R�}���h�����
	$cmd = $_[0];
	$cmd =~ s/\\"/ -->/g; #"
	$cmd =~ m/^(\w+)\s*/g;
	$name = $1;
	%arg = ();
	my($argname, $argvalue);
	while($cmd =~ m/\G(\w+)\s*=\s*"(.*?)"\s*/g) {
		$argname = $1;
		$argvalue = $2;
		$argvalue =~ s/ -->/"/g; #"
		$arg{$argname} = $argvalue;
	}
	
	if($arg{"file"}) {
		$targetfile = $indir."/".$arg{"file"};
	} elsif($arg{"virtual"}) {
		$targetfile = $root_dir."/".$arg{"virtual"};
	} else {
		$targetfile = "";
	}
	
	#�R�}���h�����s
	if($name eq "config") {
		return &cmd_config;
	} elsif($name eq "include") {
		return &cmd_include;
	} elsif($name eq "flastmod") {
		return &cmd_flastmod;
	} elsif($name eq "fsize") {
		return &cmd_fsize;
	} elsif($name eq "echo") {
		return &cmd_echo;
	} elsif($name eq "set") {
		return &cmd_set;
	} elsif($name eq "exec") {
		return &cmd_exec;
	} elsif($name eq "if") {
		unshift(@ifnest, &eval_if);
		return "";
	} elsif($name eq "elsif") {
		$ifnest[0] = (!@ifnest[0]) && &eval_if;
		return "";
	} elsif($name eq "else") {
		$ifnest[0] = !@ifnest[0];
		return "";
	} elsif($name eq "endif") {
		shift(@ifnest);
		return "";
	} elsif($name eq "input") {
		return &process_str(&cmd_include);
	} elsif($name eq "outline") {
		return &cmd_outline;
	} elsif($name eq "load_content") {
		#�t�@�C����ǂݍ���
		open(IN, $infile) or die "cannot open $infile: $!";
		
		$contents = "";
		while(<IN>) {
			$contents .= $_;
		}
		close(IN) or die "cannot close $infile: $!";
		$contents = &process_str($contents);
		return "";
	} elsif($name eq "show_content") {
		return $contents;
	} elsif($name eq "load_menu") {
		#���j���[�ǂݍ���
		open(IN, $indir."/".$echovar{"menu_file"}) or die "cannot open ".$indir."/".$echovar{"menu_file"}.": $!";
		$menu = "";
		while(<IN>) {
			$menu .= $_;
		}
		close(IN) or die "cannot close $infile: $!";
		$menu = &process_str($menu);
		return "";
	} elsif($name eq "show_menu") {
		return $menu;
	}
	return "<!--#$cmd -->";
}

#�ݒ������
sub cmd_config {
	$config_timefmt = $arg{"timefmt"} if($arg{"timefmt"});
	$config_sizefmt = lc $arg{"sizefmt"} if($arg{"sizefmt"});
	return "";
}

#�t�@�C����ǂݍ���
sub cmd_include {
	my ($include_contents);
	open(INCLUDE_FILE, $targetfile) or return "cannot open $targetfile";
	$include_contents = "";
	while(<INCLUDE_FILE>) {
		$include_contents .= $_;
	}
	close(INCLUDE_FILE);
	return $include_contents;
}

sub cmd_outline {
	my ($line, $outline, $level);
	open(INCLUDE_FILE, $targetfile) or return "cannot open $targetfile";
	$outline = "<ul>\n";
	$level = -1;
	while($line=<INCLUDE_FILE>) {
		$line =~ s/<!--.*-->//g;	#�R�����g������
		if($line =~ /<h(\d)[^>]*id="(.*)"[^>]*>(.*?)<\/h\d>/) {
			if($level < 0) {$level=$1;}
			next if($level != $1);
			$outline .= "<li><a href=\"#$2\">$3</a></li>\n";
		}
	}
	close(INCLUDE_FILE);
	$outline .= "</ul>\n";
	return $outline;
}

#�ŏI�X�V�����o��
sub cmd_flastmod {
	my @filestat = stat $targetfile;
	return strftime $config_timefmt, localtime($filestat[9]);
}

#�t�@�C���T�C�Y���o��
sub cmd_fsize {
	local $filesize = (-s $targetfile);
	if($config_sizefmt eq "abbrev") {
		if($filesize<1024) {
			return $filesize;
		} elsif($filesize<1024*1024) {
			return int($filesize/1024*10+0.5)/10 . "K";
		} elsif($filesize<1024*1024*1024) {
			return int($filesize/(1024*1024)*10+0.5)/10 . "M";
		} else {
			return int($filesize/(1024*1024*1024)*10+0.5)/10 . "G";
		}
	}
	1 while $filesize =~ s/(.*\d)(\d\d\d)/$1,$2/;
	return $filesize;
}

#�ϐ����o��
sub cmd_echo {
	return $echovar{lc $arg{"var"}} if($echovar{lc $arg{"var"}});
	return "<!--#$cmd -->";
}

#�v���O���������s
sub cmd_exec {
	return `$arg{"cmd"}` if($arg{"cmd"});
	return "<!--#$cmd -->";
}

#�ϐ��̐ݒ�
sub cmd_set {
	$echovar{lc $arg{"var"}} = $arg{"value"};
	return "";
}

#if���̎���]������
sub eval_if {
	my $expr = $arg{"expr"};
	#�������""�ň͂�
	$expr =~ s/([\ \r\t\n\f=<>\!&\|\(\)])([^\ \r\t\n\f=<>\!&\|\(\)\$]+)/$1"$2"/g;
	
	#���Z�q��perl���ɒu��
	$expr =~ s/>=/ ge /g;
	$expr =~ s/<=/ lt /g;
	$expr =~ s/>/ gt /g;
	$expr =~ s/</ lt /g;
	$expr =~ s/!=/ ne /g;
	$expr =~ s/=/ eq /g;
	
	#�ϐ���u��
	$expr =~ s/\$([A-Za-z0-9_]+)/'$echovar{"'.(lc $1).'"}'/eg;
	#print STDERR "EXPR = $expr\n";
	
	return eval($expr);
}
